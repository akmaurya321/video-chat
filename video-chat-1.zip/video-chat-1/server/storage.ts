import { 
  type User, 
  type InsertUser,
  type VideoAnalysis,
  type InsertVideoAnalysis,
  type Output,
  type InsertOutput
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Video Analysis methods
  createAnalysis(analysis: InsertVideoAnalysis): Promise<VideoAnalysis>;
  getAnalysis(id: string): Promise<VideoAnalysis | undefined>;
  updateAnalysis(id: string, updates: Partial<VideoAnalysis>): Promise<VideoAnalysis | undefined>;
  getAllAnalyses(): Promise<VideoAnalysis[]>;

  // Output methods
  createOutput(output: InsertOutput): Promise<Output>;
  getOutput(id: string): Promise<Output | undefined>;
  getOutputsByAnalysisId(analysisId: string): Promise<Output[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private analyses: Map<string, VideoAnalysis>;
  private outputs: Map<string, Output>;

  constructor() {
    this.users = new Map();
    this.analyses = new Map();
    this.outputs = new Map();
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Video Analysis methods
  async createAnalysis(insertAnalysis: InsertVideoAnalysis): Promise<VideoAnalysis> {
    const id = randomUUID();
    const analysis: VideoAnalysis = {
      ...insertAnalysis,
      id,
      status: "pending",
      currentStage: null,
      transcript: null,
      summary: null,
      entities: null,
      visualAnalysis: null,
      duration: null,
      confidence: null,
      processingTime: null,
      createdAt: new Date(),
      completedAt: null,
    };
    this.analyses.set(id, analysis);
    return analysis;
  }

  async getAnalysis(id: string): Promise<VideoAnalysis | undefined> {
    return this.analyses.get(id);
  }

  async updateAnalysis(id: string, updates: Partial<VideoAnalysis>): Promise<VideoAnalysis | undefined> {
    const analysis = this.analyses.get(id);
    if (!analysis) return undefined;

    const updated = { ...analysis, ...updates };
    this.analyses.set(id, updated);
    return updated;
  }

  async getAllAnalyses(): Promise<VideoAnalysis[]> {
    return Array.from(this.analyses.values());
  }

  // Output methods
  async createOutput(insertOutput: InsertOutput): Promise<Output> {
    const id = randomUUID();
    const output: Output = {
      ...insertOutput,
      id,
      content: insertOutput.content || null,
      generatedAt: new Date(),
    };
    this.outputs.set(id, output);
    return output;
  }

  async getOutput(id: string): Promise<Output | undefined> {
    return this.outputs.get(id);
  }

  async getOutputsByAnalysisId(analysisId: string): Promise<Output[]> {
    return Array.from(this.outputs.values()).filter(
      (output) => output.analysisId === analysisId
    );
  }
}

export const storage = new MemStorage();
