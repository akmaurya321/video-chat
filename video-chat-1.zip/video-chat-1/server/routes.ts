import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { videoProcessor } from "./services/videoProcessor";
import { insertVideoAnalysisSchema, insertOutputSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Start video analysis
  app.post("/api/analyze", async (req, res) => {
    try {
      const { videoUrl, title } = insertVideoAnalysisSchema.parse(req.body);
      
      // Create initial analysis record
      const analysis = await storage.createAnalysis({ videoUrl, title });
      
      // Start background processing
      processVideo(analysis.id, videoUrl).catch(console.error);
      
      res.json(analysis);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to start analysis" });
    }
  });

  // Get analysis status
  app.get("/api/analysis/:id", async (req, res) => {
    try {
      const analysis = await storage.getAnalysis(req.params.id);
      if (!analysis) {
        return res.status(404).json({ error: "Analysis not found" });
      }
      res.json(analysis);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch analysis" });
    }
  });

  // Generate output
  app.post("/api/generate-output", async (req, res) => {
    try {
      const { analysisId, format } = insertOutputSchema.parse(req.body);
      
      const analysis = await storage.getAnalysis(analysisId);
      if (!analysis) {
        return res.status(404).json({ error: "Analysis not found" });
      }

      let content = "";
      
      switch (format) {
        case "pdf":
          content = await videoProcessor.generatePDF(analysis);
          break;
        case "notes":
          content = await videoProcessor.generateNotes(analysis);
          break;
        case "transcript":
          content = await videoProcessor.generateAnnotatedTranscript(analysis);
          break;
        default:
          content = analysis.transcript || "";
      }

      const output = await storage.createOutput({
        analysisId,
        format,
        content
      });

      res.json(output);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to generate output" });
    }
  });

  // Download output
  app.get("/api/download/:id", async (req, res) => {
    try {
      const output = await storage.getOutput(req.params.id);
      if (!output) {
        return res.status(404).json({ error: "Output not found" });
      }

      const filename = `analysis-${output.format}.${output.format === 'pdf' ? 'pdf' : 'md'}`;
      res.setHeader('Content-Type', output.format === 'pdf' ? 'application/pdf' : 'text/markdown');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.send(output.content);
    } catch (error) {
      res.status(500).json({ error: "Failed to download output" });
    }
  });

  // List all analyses
  app.get("/api/analyses", async (req, res) => {
    try {
      const analyses = await storage.getAllAnalyses();
      res.json(analyses);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch analyses" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Background video processing
async function processVideo(analysisId: string, videoUrl: string) {
  try {
    const startTime = Date.now();

    // Stage 1: Audio Extraction & Transcription
    await storage.updateAnalysis(analysisId, {
      status: "processing",
      currentStage: "audio_extraction"
    });
    
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    await storage.updateAnalysis(analysisId, {
      currentStage: "transcription"
    });
    
    const { transcript, duration } = await videoProcessor.transcribeAudio(videoUrl);
    
    // Stage 2: Visual Analysis
    await storage.updateAnalysis(analysisId, {
      currentStage: "visual_analysis",
      transcript,
      duration
    });
    
    const visualAnalysis = await videoProcessor.analyzeVisuals(videoUrl);
    
    // Stage 3: Entity Extraction & Summarization
    await storage.updateAnalysis(analysisId, {
      currentStage: "knowledge_integration",
      visualAnalysis
    });
    
    const { entities, summary } = await videoProcessor.extractEntities(transcript);
    
    // Stage 4: Enrich with Wikipedia
    const enrichedEntities = await videoProcessor.enrichEntities(entities);
    
    // Stage 5: Finalize
    await storage.updateAnalysis(analysisId, {
      currentStage: "output_generation"
    });
    
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const processingTime = Math.floor((Date.now() - startTime) / 1000);
    const confidence = Math.floor(
      enrichedEntities.reduce((acc, e) => acc + e.confidence, 0) / 
      Math.max(enrichedEntities.length, 1)
    );
    
    await storage.updateAnalysis(analysisId, {
      status: "completed",
      currentStage: "output_generation",
      entities: enrichedEntities,
      summary,
      confidence,
      processingTime,
      completedAt: new Date()
    });
    
  } catch (error) {
    console.error("Processing error:", error);
    await storage.updateAnalysis(analysisId, {
      status: "failed",
      currentStage: null
    });
  }
}
