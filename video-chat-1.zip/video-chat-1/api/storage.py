from typing import Optional, List, Dict, Any
from datetime import datetime
from uuid import uuid4
from pydantic import BaseModel

class Entity(BaseModel):
    name: str
    type: str
    mentions: int
    confidence: int
    context: Optional[str] = None
    wikipediaData: Optional[Dict[str, Any]] = None

class VisualFrame(BaseModel):
    timestamp: int
    imageData: str
    ocrText: Optional[str] = None
    description: str
    objects: Optional[List[str]] = None

class VideoAnalysis(BaseModel):
    id: str
    videoUrl: str
    title: str
    status: str = "pending"
    currentStage: Optional[str] = None
    transcript: Optional[str] = None
    summary: Optional[str] = None
    entities: Optional[List[Entity]] = None
    visualAnalysis: Optional[List[VisualFrame]] = None
    duration: Optional[int] = None
    confidence: Optional[int] = None
    processingTime: Optional[int] = None
    createdAt: datetime
    completedAt: Optional[datetime] = None

class Output(BaseModel):
    id: str
    analysisId: str
    format: str
    content: Optional[str] = None
    generatedAt: datetime

class MemStorage:
    def __init__(self):
        self.analyses: Dict[str, VideoAnalysis] = {}
        self.outputs: Dict[str, Output] = {}

    async def create_analysis(self, video_url: str, title: str) -> VideoAnalysis:
        analysis_id = str(uuid4())
        analysis = VideoAnalysis(
            id=analysis_id,
            videoUrl=video_url,
            title=title,
            status="pending",
            currentStage=None,
            transcript=None,
            summary=None,
            entities=None,
            visualAnalysis=None,
            duration=None,
            confidence=None,
            processingTime=None,
            createdAt=datetime.now(),
            completedAt=None
        )
        self.analyses[analysis_id] = analysis
        return analysis

    async def get_analysis(self, analysis_id: str) -> Optional[VideoAnalysis]:
        return self.analyses.get(analysis_id)

    async def update_analysis(self, analysis_id: str, updates: Dict[str, Any]) -> Optional[VideoAnalysis]:
        if analysis_id not in self.analyses:
            return None
        
        analysis = self.analyses[analysis_id]
        for key, value in updates.items():
            if hasattr(analysis, key):
                setattr(analysis, key, value)
        
        return analysis

    async def get_all_analyses(self) -> List[VideoAnalysis]:
        return list(self.analyses.values())

    async def create_output(self, analysis_id: str, format: str, content: Optional[str] = None) -> Output:
        output_id = str(uuid4())
        output = Output(
            id=output_id,
            analysisId=analysis_id,
            format=format,
            content=content,
            generatedAt=datetime.now()
        )
        self.outputs[output_id] = output
        return output

    async def get_output(self, output_id: str) -> Optional[Output]:
        return self.outputs.get(output_id)

    async def get_outputs_by_analysis_id(self, analysis_id: str) -> List[Output]:
        return [output for output in self.outputs.values() if output.analysisId == analysis_id]

storage = MemStorage()
