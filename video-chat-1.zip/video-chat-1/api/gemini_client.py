import os
import logging
from google import genai
from google.genai import types
from typing import Optional

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class GeminiClient:
    def __init__(self):
        self.api_key = os.environ.get("GEMINI_API_KEY")
        if self.api_key:
            self.client = genai.Client(api_key=self.api_key)
        else:
            self.client = None
            logger.warning("GEMINI_API_KEY not found - will use demo mode")
        
    async def generate_content(
        self, 
        prompt: str, 
        model: str = "gemini-2.5-flash",
        response_format: Optional[str] = None,
        max_tokens: int = 2048
    ) -> str:
        """Generate content using Gemini API"""
        if not self.client:
            raise ValueError("GEMINI_API_KEY not found in environment variables")
        
        config = types.GenerateContentConfig(
            max_output_tokens=max_tokens,
            temperature=0.7
        )
        
        if response_format == "json":
            config.response_mime_type = "application/json"
        
        response = self.client.models.generate_content(
            model=model,
            contents=prompt,
            config=config
        )
        
        return response.text or ""
    
    async def analyze_video_file(
        self,
        video_path: str,
        prompt: str,
        model: str = "gemini-2.5-flash"
    ) -> str:
        """Analyze video file using Gemini's multimodal capabilities"""
        if not self.client:
            raise ValueError("GEMINI_API_KEY not found in environment variables")
        
        with open(video_path, "rb") as f:
            video_bytes = f.read()
            
            response = self.client.models.generate_content(
                model=model,
                contents=[
                    types.Part.from_bytes(
                        data=video_bytes,
                        mime_type="video/mp4"
                    ),
                    prompt
                ],
                config=types.GenerateContentConfig(
                    temperature=0.7,
                    max_output_tokens=4096
                )
            )
        
        return response.text or ""
    
    async def analyze_image_file(
        self,
        image_path: str,
        prompt: str,
        model: str = "gemini-2.5-flash"
    ) -> str:
        """Analyze image file using Gemini"""
        if not self.client:
            raise ValueError("GEMINI_API_KEY not found in environment variables")
        
        with open(image_path, "rb") as f:
            image_bytes = f.read()
            
            response = self.client.models.generate_content(
                model=model,
                contents=[
                    types.Part.from_bytes(
                        data=image_bytes,
                        mime_type="image/jpeg"
                    ),
                    prompt
                ]
            )
        
        return response.text or ""

gemini_client = GeminiClient()
