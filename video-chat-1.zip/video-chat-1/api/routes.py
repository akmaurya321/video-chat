import asyncio
from datetime import datetime
from typing import Dict, Any
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, HttpUrl
from api.storage import storage
from api.video_processor import video_processor

router = APIRouter()

class AnalyzeRequest(BaseModel):
    videoUrl: HttpUrl
    title: str

class GenerateOutputRequest(BaseModel):
    analysisId: str
    format: str

@router.post("/api/analyze")
async def analyze_video(request: AnalyzeRequest):
    """Start video analysis"""
    try:
        # Create initial analysis record
        analysis = await storage.create_analysis(
            video_url=str(request.videoUrl),
            title=request.title
        )
        
        # Start background processing
        asyncio.create_task(process_video(analysis.id, str(request.videoUrl)))
        
        return analysis
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to start analysis")

@router.get("/api/analysis/{analysis_id}")
async def get_analysis(analysis_id: str):
    """Get analysis status"""
    analysis = await storage.get_analysis(analysis_id)
    if not analysis:
        raise HTTPException(status_code=404, detail="Analysis not found")
    return analysis

@router.post("/api/generate-output")
async def generate_output(request: GenerateOutputRequest):
    """Generate output in specified format"""
    try:
        analysis = await storage.get_analysis(request.analysisId)
        if not analysis:
            raise HTTPException(status_code=404, detail="Analysis not found")
        
        content = ""
        
        if request.format == "pdf":
            content = await video_processor.generate_pdf(analysis)
        elif request.format == "notes":
            content = await video_processor.generate_notes(analysis)
        elif request.format == "transcript":
            content = await video_processor.generate_annotated_transcript(analysis)
        else:
            content = analysis.transcript or ""
        
        output = await storage.create_output(
            analysis_id=request.analysisId,
            format=request.format,
            content=content
        )
        
        return output
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail="Failed to generate output")

@router.get("/api/download/{output_id}")
async def download_output(output_id: str):
    """Download generated output"""
    output = await storage.get_output(output_id)
    if not output:
        raise HTTPException(status_code=404, detail="Output not found")
    
    from fastapi.responses import Response
    
    filename = f"analysis-{output.format}.{'pdf' if output.format == 'pdf' else 'md'}"
    content_type = "application/pdf" if output.format == "pdf" else "text/markdown"
    
    return Response(
        content=output.content,
        media_type=content_type,
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"'
        }
    )

@router.get("/api/analyses")
async def get_all_analyses():
    """List all analyses"""
    return await storage.get_all_analyses()

# Background video processing
async def process_video(analysis_id: str, video_url: str):
    """Process video in background"""
    try:
        import time
        start_time = time.time()
        
        # Stage 1: Audio Extraction & Transcription
        await storage.update_analysis(analysis_id, {
            "status": "processing",
            "currentStage": "audio_extraction"
        })
        
        await asyncio.sleep(1.5)
        
        await storage.update_analysis(analysis_id, {
            "currentStage": "transcription"
        })
        
        transcript, duration = await video_processor.transcribe_audio(video_url)
        
        # Stage 2: Visual Analysis
        await storage.update_analysis(analysis_id, {
            "currentStage": "visual_analysis",
            "transcript": transcript,
            "duration": duration
        })
        
        visual_analysis = await video_processor.analyze_visuals(video_url)
        
        # Stage 3: Entity Extraction & Summarization
        await storage.update_analysis(analysis_id, {
            "currentStage": "knowledge_integration",
            "visualAnalysis": visual_analysis
        })
        
        entities, summary = await video_processor.extract_entities(transcript)
        
        # Stage 4: Enrich with Wikipedia
        enriched_entities = await video_processor.enrich_entities(entities)
        
        # Stage 5: Finalize
        await storage.update_analysis(analysis_id, {
            "currentStage": "output_generation"
        })
        
        await asyncio.sleep(1)
        
        processing_time = int(time.time() - start_time)
        confidence = sum(e.confidence for e in enriched_entities) // max(len(enriched_entities), 1) if enriched_entities else 0
        
        await storage.update_analysis(analysis_id, {
            "status": "completed",
            "currentStage": "output_generation",
            "entities": enriched_entities,
            "summary": summary,
            "confidence": confidence,
            "processingTime": processing_time,
            "completedAt": datetime.now()
        })
        
    except Exception as e:
        print(f"Processing error: {e}")
        await storage.update_analysis(analysis_id, {
            "status": "failed",
            "currentStage": None
        })
