import os
import subprocess
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, HTMLResponse
from api.routes import router
import uvicorn
import httpx

app = FastAPI(title="Omni-Video Intelligencer API")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API routes
app.include_router(router)

# Check if we're in production or development
is_production = os.environ.get("NODE_ENV") == "production"
vite_process = None

if is_production:
    # Serve built frontend in production
    app.mount("/assets", StaticFiles(directory="dist/public/assets"), name="assets")
    
    @app.get("/{full_path:path}")
    async def serve_frontend(full_path: str):
        if full_path and full_path.startswith("api/"):
            return {"error": "Not found"}
        return FileResponse("dist/public/index.html")
else:
    # In development, proxy to Vite dev server
    @app.on_event("startup")
    async def start_vite():
        global vite_process
        print("Starting Vite dev server...")
        vite_process = subprocess.Popen(
            ["npx", "vite", "--host", "0.0.0.0", "--port", "5173"],
            cwd=os.getcwd()
        )
        # Wait a bit for Vite to start
        import asyncio
        await asyncio.sleep(3)
        print("✅ Vite dev server started on port 5173")
    
    @app.on_event("shutdown")
    async def stop_vite():
        global vite_process
        if vite_process:
            vite_process.terminate()
            vite_process.wait()
            print("Vite dev server stopped")
    
    @app.get("/{full_path:path}")
    async def proxy_to_vite(full_path: str, request: Request):
        # Don't proxy API requests
        if full_path.startswith("api"):
            return {"error": "Not found"}
        
        # Proxy to Vite dev server
        vite_url = f"http://localhost:5173/{full_path}" if full_path else "http://localhost:5173/"
        if request.url.query:
            vite_url += f"?{request.url.query}"
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            try:
                response = await client.get(vite_url, follow_redirects=True)
                # Filter out problematic headers
                headers = {
                    k: v for k, v in response.headers.items()
                    if k.lower() not in ('content-encoding', 'content-length', 'transfer-encoding', 'connection')
                }
                return HTMLResponse(
                    content=response.content,
                    status_code=response.status_code,
                    headers=headers
                )
            except Exception as e:
                print(f"Proxy error: {e}")
                # Fallback if Vite isn't ready yet
                return HTMLResponse("<html><body><h1>Loading Vite...</h1><script>setTimeout(() => location.reload(), 2000);</script></body></html>")

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    uvicorn.run(
        "api.main:app",
        host="0.0.0.0",
        port=port,
        reload=True if os.environ.get("NODE_ENV") == "development" else False
    )
