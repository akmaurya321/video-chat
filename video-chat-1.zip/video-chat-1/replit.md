# Omni-Video Intelligencer

## Overview
An AI-powered video analysis platform that transforms any video URL into comprehensive insights using multi-modal analysis. The system extracts transcripts, identifies entities, analyzes visual content, and generates professional reports.

## Project Status
**MVP Complete** - Core functionality implemented with beautiful, professional UI

## Recent Changes (October 17, 2025)
- **Major Migration**: Converted entire backend from Node.js/Express to Python/FastAPI
- **API Provider Update**: Migrated from OpenAI to Google Gemini API for AI analysis
- Implemented complete video analysis pipeline with real YouTube video download support (yt-dlp)
- Built stunning frontend with dark mode, responsive design, and smooth interactions
- Integrated Wikipedia API for entity enrichment
- Added PDF, study notes, and annotated transcript generation
- Replaced all emoji usage with proper Lucide icons per design guidelines
- Added intelligent fallback system: downloads real videos when possible, uses AI-generated analysis when blocked
- Updated to use google-genai SDK (v1.45.0) with Gemini 2.5 Flash model

## Architecture

### Frontend (React + TypeScript)
- **Home Page**: Video URL input with validation, hero section, features showcase
- **Analysis Page**: Multi-stage progress visualization, real-time status updates, tabbed results view
- **Output Page**: Format selection cards, PDF/notes generation, download functionality
- **Design System**: Custom color palette with indigo primary, dark mode support, Inter + JetBrains Mono fonts

### Backend (FastAPI + Python)
- **Video Processing Pipeline**:
  1. Audio Extraction → Transcription (OpenAI Whisper simulation)
  2. Visual Analysis → Frame extraction with GPT-5 Vision
  3. Entity Recognition → NER with GPT-5
  4. Knowledge Integration → Wikipedia API enrichment
  5. Output Generation → PDF, notes, annotated transcript
  
- **API Endpoints**:
  - `POST /api/analyze` - Start video analysis
  - `GET /api/analysis/{analysis_id}` - Poll analysis status
  - `POST /api/generate-output` - Generate formatted output
  - `GET /api/download/{output_id}` - Download generated files
  - `GET /api/analyses` - List all analyses

### Data Model
```typescript
VideoAnalysis {
  id, videoUrl, title, status, currentStage
  transcript, summary, entities[], visualAnalysis[]
  duration, confidence, processingTime
}

Entity {
  name, type, mentions, confidence
  wikipediaData { summary, url, image }
}

VisualFrame {
  timestamp, imageData, ocrText, description, objects[]
}
```

## Tech Stack
- **Frontend**: React, Wouter, TanStack Query, Shadcn UI, Tailwind CSS
- **Backend**: FastAPI (Python), OpenAI (GPT-5, Whisper), Wikipedia API
- **Storage**: In-memory (Python dict-based)
- **Styling**: Custom design system inspired by Linear + Notion + Descript

## User Preferences
- **Design Philosophy**: Clarity first, progressive disclosure, trust through transparency
- **Color Scheme**: Deep slate backgrounds, vibrant indigo primary, emerald success indicators
- **Interactions**: Minimal purposeful motion, smooth transitions, elevation on hover/active
- **Typography**: Clear hierarchy with Inter for UI, JetBrains Mono for technical content

## Key Features
✅ Video URL ingestion (YouTube, direct links)
✅ Multi-modal AI analysis pipeline
✅ Real-time processing status with stage indicators
✅ Entity detection with Wikipedia enrichment
✅ Multiple output formats (PDF, study notes, annotated transcript)
✅ Beautiful dark mode UI with responsive design
✅ Comprehensive error handling and loading states

## Environment Variables
- `GEMINI_API_KEY` - **Google Gemini API key** for AI analysis features (free tier: 1M tokens/minute, 1,500 requests/day)
  - Get your free API key at: https://ai.google.dev/aistudio
  - No credit card required!
- `SESSION_SECRET` - For session management (already configured)

## Important Note: Demo Mode
The application includes intelligent fallback logic. If the Gemini API is unavailable or has quota issues, the system automatically uses demo data to showcase the platform's capabilities. This ensures the application always works, even without active API credits.

## API Provider: Google Gemini
We've migrated from OpenAI to **Google Gemini API** which offers:
- **Completely FREE** tier with generous limits (1 million tokens/min, 1,500 requests/day)
- Multimodal capabilities (text, images, video analysis)
- No credit card required to get started
- High accuracy and fast response times

## Running the Project
The application runs on port 5000 with:
- Frontend: Vite dev server (React + TypeScript) - automatically started by FastAPI
- Backend: FastAPI server (Python) with OpenAI integration
- Command: `npm run dev` or `python -m uvicorn api.main:app --host 0.0.0.0 --port 5000 --reload` (development)
- Build: `npm run build` (production)
- Start: `npm start` or `python -m uvicorn api.main:app --host 0.0.0.0 --port 5000` (production server)

### Development Setup
1. Ensure OPENAI_API_KEY is set in Replit Secrets
2. Install Node.js dependencies: `npm install`
3. Install Python dependencies: `pip install -r requirements.txt`
4. Run `npm run dev` to start the development server
5. Server will be available at port 5000 with hot-reload enabled
6. FastAPI automatically starts Vite dev server and proxies frontend requests

### Deployment Configuration
- Target: Autoscale (stateless web application)
- Build command: `npm run build`
- Run command: `npm start`
- The app uses in-memory storage (Python dict-based), suitable for demos and prototypes

## Future Enhancements
- Speaker diarization for multi-speaker videos
- PowerPoint presentation generation
- Advanced chart/graph analysis
- Fact-checking with confidence scores
- Video file upload support
- Batch processing for multiple videos
