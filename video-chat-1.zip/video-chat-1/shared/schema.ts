import { sql } from "drizzle-orm";
import { pgTable, text, varchar, jsonb, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const videoAnalyses = pgTable("video_analyses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  videoUrl: text("video_url").notNull(),
  title: text("title").notNull(),
  status: text("status").notNull().default("pending"), // pending, processing, completed, failed
  currentStage: text("current_stage"), // audio_extraction, visual_analysis, transcription, knowledge_integration, output_generation
  
  // Processing results
  transcript: text("transcript"),
  summary: text("summary"),
  entities: jsonb("entities").$type<Entity[]>(),
  visualAnalysis: jsonb("visual_analysis").$type<VisualFrame[]>(),
  
  // Metadata
  duration: integer("duration"), // in seconds
  confidence: integer("confidence"), // 0-100
  processingTime: integer("processing_time"), // in seconds
  
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const outputs = pgTable("outputs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  analysisId: varchar("analysis_id").notNull().references(() => videoAnalyses.id),
  format: text("format").notNull(), // pdf, pptx, notes, transcript
  content: text("content"), // File path or content
  generatedAt: timestamp("generated_at").defaultNow(),
});

// TypeScript types for complex data structures
export interface Entity {
  name: string;
  type: "person" | "organization" | "location" | "concept" | "date";
  mentions: number;
  confidence: number;
  context?: string;
  wikipediaData?: {
    summary: string;
    url: string;
    image?: string;
  };
}

export interface VisualFrame {
  timestamp: number;
  imageData: string; // base64 or URL
  ocrText?: string;
  description: string;
  objects?: string[];
}

export interface ProcessingStage {
  stage: string;
  status: "pending" | "processing" | "completed" | "failed";
  message?: string;
}

// Zod schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertVideoAnalysisSchema = createInsertSchema(videoAnalyses, {
  videoUrl: z.string().url(),
  title: z.string().min(1),
}).omit({
  id: true,
  createdAt: true,
  completedAt: true,
});

export const insertOutputSchema = createInsertSchema(outputs, {
  format: z.enum(["pdf", "pptx", "notes", "transcript"]),
}).omit({
  id: true,
  generatedAt: true,
});

// Inferred types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertVideoAnalysis = z.infer<typeof insertVideoAnalysisSchema>;
export type VideoAnalysis = typeof videoAnalyses.$inferSelect;

export type InsertOutput = z.infer<typeof insertOutputSchema>;
export type Output = typeof outputs.$inferSelect;
