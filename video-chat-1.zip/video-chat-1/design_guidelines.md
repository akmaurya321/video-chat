# Omni-Video Intelligencer - Design Guidelines

## Design Approach: Modern Productivity Platform

**Selected System**: Custom design inspired by Linear + Notion + Descript
**Rationale**: Professional AI analysis tool requiring clean information hierarchy, workflow clarity, and trustworthy presentation of complex data

---

## Core Design Principles

1. **Clarity First**: Every processing stage must be visually distinct and understandable
2. **Progressive Disclosure**: Show complexity only when needed
3. **Trust Through Transparency**: Visualize AI processing confidence and sources
4. **Workflow Continuity**: Seamless progression from upload to output

---

## Color Palette

### Dark Mode (Primary)
- **Background**: 222 15% 8% (deep slate)
- **Surface**: 222 15% 12% (elevated slate)
- **Surface Elevated**: 222 15% 16%
- **Primary Brand**: 250 95% 65% (vibrant indigo) - conveys AI intelligence
- **Success**: 142 76% 56% (emerald)
- **Warning**: 38 92% 50% (amber)
- **Text Primary**: 0 0% 98%
- **Text Secondary**: 0 0% 65%

### Light Mode
- **Background**: 0 0% 100%
- **Surface**: 220 20% 97%
- **Surface Elevated**: 220 20% 99%
- **Primary Brand**: 250 95% 55%

---

## Typography

**Families**: 
- Primary: Inter (via Google Fonts) - UI elements, body text
- Monospace: JetBrains Mono - code, timestamps, technical data

**Scale**:
- Hero/H1: text-4xl md:text-5xl font-bold
- H2: text-3xl font-semibold  
- H3: text-xl font-semibold
- Body: text-base font-normal
- Small/Meta: text-sm text-secondary

---

## Layout System

**Spacing Primitives**: Use Tailwind units of **2, 4, 6, 8, 12, 16** for consistency
- Component padding: p-4 to p-8
- Section spacing: py-12 to py-16
- Element gaps: gap-4 to gap-6

**Container Strategy**:
- Dashboard/App: max-w-7xl mx-auto px-4
- Content width: max-w-4xl for readability
- Full-bleed sections: w-full with controlled inner width

---

## Component Architecture

### Navigation
- **Top Bar**: Sticky header (h-16) with logo, main nav, user profile
- **Sidebar** (Dashboard): Fixed left sidebar (w-64) for project navigation, recent videos
- Clean, minimal design with subtle hover states (bg-surface-elevated)

### Upload Interface (Landing/Home)
- **Drag-and-Drop Zone**: Large, centered area (min-h-96) with dashed border
- Two input methods: File upload + URL input (tabs or side-by-side)
- Visual feedback: Animated border on drag-over, progress indicator on upload
- Format support badges displayed clearly

### Processing Dashboard
- **Progress Visualization**: Multi-stage progress bar showing:
  - Audio Extraction → Visual Analysis → Transcription → Knowledge Integration → Output Generation
  - Each stage with icon, label, status (pending/processing/complete)
- **Live Preview Card**: Video thumbnail + real-time processing updates
- **Confidence Indicators**: Color-coded badges (green/amber/red) for AI certainty

### Analysis Results View
- **Multi-Panel Layout**:
  - Left: Video player with timestamp navigation
  - Center: Tabbed content (Transcript, Entities, Visual Analysis, Summary)
  - Right: Context panel showing enriched knowledge for selected entities
- **Entity Cards**: Hoverable chips that reveal Wikipedia/knowledge graph data in popover
- **Visual Annotations**: Timestamped screenshots with OCR overlays displayed in gallery grid

### Output Selection
- **Format Cards**: Grid of output types (2x2 on desktop, stacked mobile)
  - Each card shows icon, title, description, "Generate" CTA
  - Preview thumbnails of sample outputs
- **Customization Panel**: Collapsible options for each format (sections to include, detail level)

### Document Preview
- **Split View**: Generated document preview (left) + download/share actions (right)
- **PDF Preview**: Embedded viewer with page thumbnails
- **Presentation Preview**: Slide carousel with navigation
- **Annotations**: Inline links to source timestamps in original video

---

## Data Visualization

- **Transcript Display**: Line-numbered, speaker-labeled, with confidence scores
- **Timeline View**: Horizontal timeline showing topic segments with color coding
- **Entity Network**: Optional graph view showing relationships between detected entities
- **Statistics Cards**: Key metrics (entities found, processing time, confidence average) in dashboard cards

---

## Interactive Elements

### Buttons
- Primary: bg-primary text-white with subtle glow effect (shadow-lg shadow-primary/20)
- Secondary: border border-primary/30 text-primary
- On images: backdrop-blur-md bg-white/10 border border-white/20 (no hover states needed)

### Cards
- Elevated surfaces with border border-surface-elevated
- Hover: Subtle lift (translate-y-[-2px]) + shadow increase
- Clickable cards: cursor-pointer with smooth transitions

### Forms
- Input fields: bg-surface border border-surface-elevated focus:border-primary
- Consistent h-12 for all inputs
- Clear labels with text-sm text-secondary above fields

---

## Images & Media

### Hero Section (Marketing Landing Page if applicable)
- Large hero image showing AI analyzing a video with visual overlays
- Abstract visualization of multi-modal processing (audio waves + visual frames + text)
- Gradient overlay for text legibility

### Dashboard Images
- Video thumbnails: 16:9 aspect ratio, rounded corners (rounded-lg)
- Entity images: Circular avatars for people, square for concepts/places
- Icon library: Heroicons for UI elements

**Images Needed**:
1. Hero: AI processing visualization (abstract tech aesthetic)
2. Feature screenshots: Dashboard, analysis view, output formats
3. Entity avatars: Placeholder for detected people/organizations
4. Brand elements: Logo variations for light/dark modes

---

## Accessibility & Responsiveness

- Maintain WCAG AA contrast ratios (4.5:1 text, 3:1 UI)
- Dark mode inputs: bg-surface with visible borders
- Mobile: Stack sidebars, collapse navigation to hamburger
- Keyboard navigation: Focus rings on all interactive elements (ring-2 ring-primary)
- Screen reader labels for all icon-only buttons

---

## Animation Philosophy

**Minimal, Purposeful Motion**:
- Page transitions: Subtle fade (150ms)
- Processing states: Pulsing indicators for active tasks
- Success states: Checkmark animation on completion
- Avoid: Excessive parallax, scroll-triggered animations, decorative motion

---

## Unique Design Elements

1. **AI Confidence Meter**: Visual indicator showing analysis reliability (gradient bar)
2. **Knowledge Connector**: Animated lines linking transcript entities to knowledge panel
3. **Multi-Modal Tabs**: Icon-driven tabs for Audio/Visual/Text analysis with color coding
4. **Smart Highlights**: Auto-highlighted key moments in transcript based on importance

---

This design balances professional credibility with modern AI-tool aesthetics, ensuring users trust the platform while efficiently navigating complex multi-modal analysis workflows.