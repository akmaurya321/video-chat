import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { 
  CheckCircle2, 
  Loader2, 
  ArrowLeft,
  FileText,
  Users,
  Image as ImageIcon,
  Sparkles,
  Download,
  Globe,
  Clock,
  Music,
  Eye,
  FileEdit,
  Network
} from "lucide-react";
import { ThemeToggle } from "@/components/theme-toggle";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { VideoAnalysis, Entity, VisualFrame } from "@shared/schema";

const STAGES = [
  { id: "audio_extraction", label: "Audio Extraction", icon: Music },
  { id: "transcription", label: "Transcription", icon: FileEdit },
  { id: "visual_analysis", label: "Visual Analysis", icon: Eye },
  { id: "knowledge_integration", label: "Knowledge Integration", icon: Network },
  { id: "output_generation", label: "Output Ready", icon: Sparkles }
];

export default function Analyze() {
  const [, setLocation] = useLocation();
  const searchParams = new URLSearchParams(window.location.search);
  const videoUrl = searchParams.get("url");
  const [analysisId, setAnalysisId] = useState<string | null>(null);

  // Start analysis mutation
  const startAnalysis = useMutation({
    mutationFn: async (url: string) => {
      // Extract title from URL
      const youtubeMatch = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&\s]+)/);
      const title = youtubeMatch 
        ? `YouTube Video: ${youtubeMatch[1]}` 
        : url.split('/').pop() || "Video Analysis";
      
      const response = await apiRequest("POST", "/api/analyze", { 
        videoUrl: url,
        title 
      });
      return await response.json() as VideoAnalysis;
    },
    onSuccess: (data: VideoAnalysis) => {
      setAnalysisId(data.id);
    }
  });

  // Poll for analysis status
  const { data: analysis, isLoading } = useQuery<VideoAnalysis>({
    queryKey: ["/api/analysis", analysisId],
    enabled: !!analysisId,
    refetchInterval: (query) => {
      const data = query.state.data;
      return data?.status === "completed" || data?.status === "failed" ? false : 2000;
    },
  });

  useEffect(() => {
    if (videoUrl && !analysisId) {
      startAnalysis.mutate(videoUrl);
    }
  }, [videoUrl]);

  if (!videoUrl) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>No Video URL Provided</CardTitle>
          </CardHeader>
          <CardContent>
            <Button onClick={() => setLocation("/")} data-testid="button-back-home">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const currentStageIndex = STAGES.findIndex(s => s.id === analysis?.currentStage);
  const progressPercent = analysis?.status === "completed" ? 100 : 
    currentStageIndex >= 0 ? ((currentStageIndex + 1) / STAGES.length) * 100 : 0;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between max-w-7xl mx-auto px-4">
          <Button 
            variant="ghost" 
            onClick={() => setLocation("/")}
            data-testid="button-back"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <ThemeToggle />
        </div>
      </header>

      <div className="container max-w-7xl mx-auto px-4 py-8">
        {/* Processing Status */}
        <Card className="mb-8">
          <CardHeader>
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div>
                <CardTitle className="text-2xl mb-2" data-testid="text-analysis-title">
                  {analysis?.title || "Processing Video..."}
                </CardTitle>
                <p className="text-sm text-muted-foreground truncate max-w-2xl" data-testid="text-video-url">
                  {videoUrl}
                </p>
              </div>
              <Badge 
                variant={analysis?.status === "completed" ? "default" : "secondary"}
                className="text-sm px-4 py-1"
                data-testid={`badge-status-${analysis?.status || 'processing'}`}
              >
                {analysis?.status === "completed" && <CheckCircle2 className="w-4 h-4 mr-2" />}
                {analysis?.status === "processing" && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                {analysis?.status || "Initializing"}
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {/* Progress Bar */}
              <div className="space-y-2">
                <Progress value={progressPercent} className="h-2" data-testid="progress-analysis" />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Processing stages</span>
                  <span>{Math.round(progressPercent)}%</span>
                </div>
              </div>

              {/* Stage Indicators */}
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                {STAGES.map((stage, index) => {
                  const isActive = analysis?.currentStage === stage.id;
                  const isCompleted = currentStageIndex > index || analysis?.status === "completed";
                  const StageIcon = stage.icon;
                  
                  return (
                    <div 
                      key={stage.id}
                      className={`flex flex-col items-center gap-2 p-4 rounded-md border transition-colors ${
                        isActive ? "border-primary bg-primary/5" : 
                        isCompleted ? "border-chart-2 bg-chart-2/5" : 
                        "border-border"
                      }`}
                      data-testid={`stage-${stage.id}`}
                    >
                      <StageIcon className={`w-6 h-6 ${isActive ? "text-primary" : isCompleted ? "text-chart-2" : "text-muted-foreground"}`} data-testid={`icon-stage-${stage.id}`} />
                      <span className="text-xs text-center font-medium" data-testid={`text-stage-label-${stage.id}`}>{stage.label}</span>
                      {isCompleted && <CheckCircle2 className="w-4 h-4 text-chart-2" data-testid={`icon-stage-complete-${stage.id}`} />}
                      {isActive && <Loader2 className="w-4 h-4 text-primary animate-spin" data-testid={`icon-stage-active-${stage.id}`} />}
                    </div>
                  );
                })}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results */}
        {analysis?.status === "completed" && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              <Tabs defaultValue="summary" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="summary" data-testid="tab-summary">
                    <Sparkles className="w-4 h-4 mr-2" />
                    Summary
                  </TabsTrigger>
                  <TabsTrigger value="transcript" data-testid="tab-transcript">
                    <FileText className="w-4 h-4 mr-2" />
                    Transcript
                  </TabsTrigger>
                  <TabsTrigger value="entities" data-testid="tab-entities">
                    <Users className="w-4 h-4 mr-2" />
                    Entities
                  </TabsTrigger>
                  <TabsTrigger value="visuals" data-testid="tab-visuals">
                    <ImageIcon className="w-4 h-4 mr-2" />
                    Visuals
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="summary" className="mt-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Executive Summary</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-base leading-relaxed whitespace-pre-wrap" data-testid="text-summary">
                        {analysis.summary || "Generating summary..."}
                      </p>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="transcript" className="mt-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Full Transcript</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ScrollArea className="h-[500px] w-full pr-4">
                        <div className="font-mono text-sm leading-relaxed whitespace-pre-wrap" data-testid="text-transcript">
                          {analysis.transcript || "No transcript available"}
                        </div>
                      </ScrollArea>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="entities" className="mt-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Detected Entities</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {analysis.entities?.map((entity: Entity, index: number) => (
                          <div key={index} className="space-y-2">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <Badge variant="outline" data-testid={`badge-entity-type-${index}`}>
                                  {entity.type}
                                </Badge>
                                <span className="font-medium" data-testid={`text-entity-name-${index}`}>{entity.name}</span>
                              </div>
                              <Badge variant="secondary" data-testid={`badge-entity-mentions-${index}`}>{entity.mentions} mentions</Badge>
                            </div>
                            {entity.wikipediaData?.summary && (
                              <p className="text-sm text-muted-foreground pl-4" data-testid={`text-entity-summary-${index}`}>
                                {entity.wikipediaData.summary}
                              </p>
                            )}
                            {index < (analysis.entities?.length || 0) - 1 && <Separator />}
                          </div>
                        ))}
                        {(!analysis.entities || analysis.entities.length === 0) && (
                          <p className="text-sm text-muted-foreground">No entities detected</p>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="visuals" className="mt-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Visual Analysis</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {analysis.visualAnalysis?.map((frame: VisualFrame, index: number) => (
                          <div key={index} className="space-y-2 p-4 border rounded-md" data-testid={`visual-frame-${index}`}>
                            <div className="flex items-center gap-2 text-sm text-muted-foreground" data-testid={`text-frame-timestamp-${index}`}>
                              <Clock className="w-4 h-4" />
                              {Math.floor(frame.timestamp / 60)}:{(frame.timestamp % 60).toString().padStart(2, '0')}
                            </div>
                            <p className="text-sm" data-testid={`text-frame-description-${index}`}>{frame.description}</p>
                            {frame.ocrText && (
                              <div className="text-xs font-mono bg-muted p-2 rounded" data-testid={`text-frame-ocr-${index}`}>
                                {frame.ocrText}
                              </div>
                            )}
                          </div>
                        ))}
                        {(!analysis.visualAnalysis || analysis.visualAnalysis.length === 0) && (
                          <p className="text-sm text-muted-foreground col-span-2">No visual analysis available</p>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Stats */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Analysis Stats</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Duration</span>
                    <span className="font-medium" data-testid="text-duration">
                      {analysis.duration ? `${Math.floor(analysis.duration / 60)}:${(analysis.duration % 60).toString().padStart(2, '0')}` : "N/A"}
                    </span>
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Confidence</span>
                    <Badge variant={
                      (analysis.confidence || 0) > 80 ? "default" : 
                      (analysis.confidence || 0) > 60 ? "secondary" : 
                      "outline"
                    } data-testid="badge-confidence">
                      {analysis.confidence || 0}%
                    </Badge>
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Entities Found</span>
                    <span className="font-medium" data-testid="text-entities-count">
                      {analysis.entities?.length || 0}
                    </span>
                  </div>
                </CardContent>
              </Card>

              {/* Generate Report */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Generate Report</CardTitle>
                </CardHeader>
                <CardContent>
                  <Button 
                    className="w-full shadow-lg shadow-primary/20"
                    onClick={() => setLocation(`/output/${analysisId}`)}
                    data-testid="button-generate-report"
                  >
                    <FileText className="w-4 h-4 mr-2" />
                    Create PDF Report
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
