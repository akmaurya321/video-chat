import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Video, 
  Sparkles, 
  FileText, 
  Brain, 
  Globe, 
  ChevronRight,
  Youtube,
  PlayCircle
} from "lucide-react";
import { ThemeToggle } from "@/components/theme-toggle";

export default function Home() {
  const [, setLocation] = useLocation();
  const [videoUrl, setVideoUrl] = useState("");
  const [isValidUrl, setIsValidUrl] = useState(false);

  const handleUrlChange = (url: string) => {
    setVideoUrl(url);
    try {
      const urlObj = new URL(url);
      setIsValidUrl(
        urlObj.protocol === "http:" || 
        urlObj.protocol === "https:"
      );
    } catch {
      setIsValidUrl(false);
    }
  };

  const handleAnalyze = () => {
    if (isValidUrl) {
      setLocation(`/analyze?url=${encodeURIComponent(videoUrl)}`);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between max-w-7xl mx-auto px-4">
          <div className="flex items-center gap-2">
            <div className="flex items-center justify-center w-9 h-9 rounded-md bg-primary">
              <Sparkles className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-semibold">Omni-Video Intelligencer</span>
          </div>
          <ThemeToggle />
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 md:py-24">
        <div className="container max-w-7xl mx-auto px-4">
          <div className="flex flex-col items-center text-center gap-8">
            <Badge variant="secondary" className="text-sm px-4 py-1">
              <Sparkles className="w-3 h-3 mr-2" />
              AI-Powered Multi-Modal Analysis
            </Badge>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold max-w-4xl">
              Transform Videos into
              <span className="text-primary"> Comprehensive Insights</span>
            </h1>
            
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl">
              Extract transcripts, identify entities, analyze visuals, and generate professional reports from any video with cutting-edge AI technology.
            </p>

            {/* URL Input */}
            <Card className="w-full max-w-2xl p-6">
              <div className="flex flex-col gap-4">
                <div className="flex items-center gap-2">
                  <Video className="w-5 h-5 text-muted-foreground" />
                  <label className="text-sm font-medium">Video URL</label>
                </div>
                <div className="flex gap-2">
                  <Input
                    type="url"
                    placeholder="https://www.youtube.com/watch?v=..."
                    value={videoUrl}
                    onChange={(e) => handleUrlChange(e.target.value)}
                    className="h-12 text-base"
                    data-testid="input-video-url"
                  />
                  <Button 
                    onClick={handleAnalyze}
                    disabled={!isValidUrl}
                    className="h-12 px-8 shadow-lg shadow-primary/20"
                    data-testid="button-analyze"
                  >
                    Analyze
                    <ChevronRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs text-muted-foreground">Supports:</span>
                  <Badge variant="outline" className="text-xs">
                    <Youtube className="w-3 h-3 mr-1" />
                    YouTube
                  </Badge>
                  <Badge variant="outline" className="text-xs">
                    <PlayCircle className="w-3 h-3 mr-1" />
                    Direct Links
                  </Badge>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-16 bg-card/50">
        <div className="container max-w-7xl mx-auto px-4">
          <h2 className="text-3xl font-semibold text-center mb-12">
            Powerful AI Analysis Pipeline
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="p-6 hover-elevate transition-transform cursor-default">
              <div className="flex items-center justify-center w-12 h-12 rounded-md bg-primary/10 mb-4">
                <Video className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Audio Transcription</h3>
              <p className="text-sm text-muted-foreground">
                High-accuracy speech-to-text conversion using OpenAI Whisper
              </p>
            </Card>

            <Card className="p-6 hover-elevate transition-transform cursor-default">
              <div className="flex items-center justify-center w-12 h-12 rounded-md bg-chart-2/10 mb-4">
                <Brain className="w-6 h-6 text-chart-2" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Visual Analysis</h3>
              <p className="text-sm text-muted-foreground">
                Extract text, identify objects, and analyze visual content with AI
              </p>
            </Card>

            <Card className="p-6 hover-elevate transition-transform cursor-default">
              <div className="flex items-center justify-center w-12 h-12 rounded-md bg-chart-3/10 mb-4">
                <Globe className="w-6 h-6 text-chart-3" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Knowledge Integration</h3>
              <p className="text-sm text-muted-foreground">
                Enrich entities with Wikipedia data and external knowledge sources
              </p>
            </Card>

            <Card className="p-6 hover-elevate transition-transform cursor-default">
              <div className="flex items-center justify-center w-12 h-12 rounded-md bg-chart-1/10 mb-4">
                <FileText className="w-6 h-6 text-chart-1" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Report Generation</h3>
              <p className="text-sm text-muted-foreground">
                Create professional PDFs with summaries, insights, and annotations
              </p>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
