import { useEffect, useState } from "react";
import { useLocation, useRoute } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowLeft, 
  FileText, 
  Download, 
  CheckCircle2,
  Loader2,
  FileSpreadsheet,
  File
} from "lucide-react";
import { ThemeToggle } from "@/components/theme-toggle";
import { apiRequest } from "@/lib/queryClient";
import type { VideoAnalysis, Output } from "@shared/schema";

const OUTPUT_FORMATS = [
  {
    id: "pdf",
    title: "Comprehensive Report",
    description: "Detailed PDF with executive summary, transcript, entity analysis, and visual insights",
    icon: FileText,
    color: "text-chart-1"
  },
  {
    id: "notes",
    title: "Study Notes",
    description: "Concise markdown notes with key takeaways, definitions, and Q&A section",
    icon: File,
    color: "text-chart-2"
  },
  {
    id: "transcript",
    title: "Annotated Transcript",
    description: "Full transcript with contextual annotations and external source links",
    icon: FileSpreadsheet,
    color: "text-chart-3"
  }
];

export default function OutputPage() {
  const [, setLocation] = useLocation();
  const [, params] = useRoute("/output/:id");
  const analysisId = params?.id;
  const [selectedFormat, setSelectedFormat] = useState<string | null>(null);
  const [generatedOutput, setGeneratedOutput] = useState<Output | null>(null);

  const { data: analysis } = useQuery<VideoAnalysis>({
    queryKey: ["/api/analysis", analysisId],
    enabled: !!analysisId,
  });

  const generateOutput = useMutation({
    mutationFn: async (format: string) => {
      const response = await apiRequest("POST", "/api/generate-output", {
        analysisId,
        format
      });
      return await response.json() as Output;
    },
    onSuccess: (data: Output) => {
      setGeneratedOutput(data);
    }
  });

  const handleGenerate = (format: string) => {
    setSelectedFormat(format);
    generateOutput.mutate(format);
  };

  const handleDownload = () => {
    if (generatedOutput?.content) {
      // Trigger download
      const link = document.createElement('a');
      link.href = `/api/download/${generatedOutput.id}`;
      link.download = `analysis-${generatedOutput.format}.${generatedOutput.format === 'pdf' ? 'pdf' : 'md'}`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  if (!analysisId) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>Invalid Analysis</CardTitle>
          </CardHeader>
          <CardContent>
            <Button onClick={() => setLocation("/")} data-testid="button-back-home">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between max-w-7xl mx-auto px-4">
          <Button 
            variant="ghost" 
            onClick={() => setLocation(`/analyze?url=${encodeURIComponent(analysis?.videoUrl || '')}`)}
            data-testid="button-back"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Analysis
          </Button>
          <ThemeToggle />
        </div>
      </header>

      <div className="container max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2" data-testid="heading-output">Generate Output</h1>
          <p className="text-muted-foreground" data-testid="text-output-description">
            Choose a format to generate your comprehensive video analysis report
          </p>
        </div>

        {/* Format Selection */}
        {!generatedOutput && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {OUTPUT_FORMATS.map((format) => {
              const Icon = format.icon;
              const isGenerating = selectedFormat === format.id && generateOutput.isPending;
              
              return (
                <Card 
                  key={format.id}
                  className="hover-elevate transition-all cursor-pointer"
                  onClick={() => !isGenerating && handleGenerate(format.id)}
                  data-testid={`card-format-${format.id}`}
                >
                  <CardHeader>
                    <div className="flex items-center justify-center w-12 h-12 rounded-md bg-primary/10 mb-4">
                      <Icon className={`w-6 h-6 ${format.color}`} data-testid={`icon-format-${format.id}`} />
                    </div>
                    <CardTitle className="text-xl" data-testid={`text-format-title-${format.id}`}>{format.title}</CardTitle>
                    <CardDescription className="text-sm" data-testid={`text-format-description-${format.id}`}>
                      {format.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button 
                      className="w-full"
                      disabled={isGenerating}
                      data-testid={`button-generate-${format.id}`}
                    >
                      {isGenerating ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Generating...
                        </>
                      ) : (
                        <>
                          <FileText className="w-4 h-4 mr-2" />
                          Generate
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        {/* Generated Output */}
        {generatedOutput && (
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between flex-wrap gap-4">
                <div>
                  <CardTitle className="text-2xl mb-2" data-testid="text-output-title">
                    {OUTPUT_FORMATS.find(f => f.id === generatedOutput.format)?.title}
                  </CardTitle>
                  <CardDescription data-testid="text-output-status">
                    Generated successfully
                  </CardDescription>
                </div>
                <Badge variant="default" className="text-sm px-4 py-1">
                  <CheckCircle2 className="w-4 h-4 mr-2" />
                  Ready
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Preview */}
              <div className="bg-muted rounded-md p-6">
                <h3 className="font-semibold mb-4">Preview</h3>
                <div className="bg-background rounded border p-4 max-h-96 overflow-y-auto">
                  <pre className="text-sm whitespace-pre-wrap font-mono" data-testid="text-output-preview">
                    {generatedOutput.content?.substring(0, 1000)}...
                  </pre>
                </div>
              </div>

              {/* Download */}
              <div className="flex gap-4 flex-wrap">
                <Button 
                  className="shadow-lg shadow-primary/20"
                  onClick={handleDownload}
                  data-testid="button-download"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download {generatedOutput.format.toUpperCase()}
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => setGeneratedOutput(null)}
                  data-testid="button-generate-another"
                >
                  Generate Another Format
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
